# medk

Mobile-first AI assistant with chat history, voice input, and spoken replies.

## Render
Root Directory: `server`
Build Command: `npm install`
Start Command: `npm start`

Add environment variable:
`OPENAI_API_KEY` = your API key

Do not put the API key inside `index.html` or commit `.env`.
